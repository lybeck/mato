---
-- Provides an interface to the user's filesystem.
-- 
-- This module provides access to files in two places, and two places only:
-- 
-- Each game is granted a single directory on the system where files can be saved 
-- through love.filesystem. This is the only directory where love.filesystem 
-- can write files. These directories will typically be found in something like:
-- 
-- Files that are opened for write or append will always be created in the save directory. 
-- The same goes for other operations that involve writing to the filesystem, 
-- like mkdir.
-- 
-- Files that are opened for read will be looked for in the save directory, and then 
-- in the .love archive (in that order). So if a file with a certain filename (and 
-- path) exist in both the .love archive and the save folder, the one in the save 
-- directory takes precedence.
-- 
-- Note: All paths are relative to the .love archive and save directory. (except 
-- for the get*Directory() calls)
-- 
-- It is recommended to set your game's identity first in your conf.lua. You can 
-- set it with love.filesystem.setIdentity() as well.
-- 
-- Dansk – Deutsch – English – Español – Français – Indonesia – Italiano – 
-- Lietuviškai – Magyar – Nederlands – Polski – Português – Română – Slovenský – 
-- Suomi – Svenska – Türkçe – Česky – Ελληνικά – Български – Русский – Српски – 
-- Українська – עברית – ไทย – 日本語 – 正體中文 – 简体中文 – Tiếng Việt – 한국어 More info
-- 
-- @module filesystem
--

---
-- Append data to an existing file.
-- 
-- @function [parent = #filesystem] append
-- @param #string name The name (and path) of the file.
-- @param #string data The string data to append to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success True if the operation was successful, or nil if there was an error.
-- @return #string errormsg The error message on failure.

---
-- Append data to an existing file.
-- 
-- @function [parent = #filesystem] append
-- @param #string name The name (and path) of the file.
-- @param #Data data The Data object to append to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success True if the operation was successful, or nil if there was an error.
-- @return #string errormsg The error message on failure.

---
-- Recursively creates a directory.
-- 
-- When called with "a/b" it creates both "a" and "a/b", if they don't exist already.
-- 
-- @function [parent = #filesystem] createDirectory
-- @param #string name The directory to create.
-- @return #boolean ok True if the directory was created, false if not.

---
-- Returns a table with the names of files and subdirectories in the specified 
-- path. The table is not sorted in any way; the order is undefined.
-- 
-- If the path passed to the function exists in the game and the save directory, 
-- it will list the files and directories from both places.
-- 
-- @function [parent = #filesystem] enumerate
-- @param #string dir The directory.
-- @return #table files A sequence with the names of all files and subdirectories as strings.

---
-- Check whether a file or directory exists.
-- 
-- @function [parent = #filesystem] exists
-- @param #string filename The path to a potential file or directory.
-- @return #boolean e True if there is a file or directory with the specified name. False otherwise.

---
-- Returns the application data directory (could be the same as getUserDirectory)
-- 
-- @function [parent = #filesystem] getAppdataDirectory
-- @return #string path The path of the application data directory

---
-- Returns a table with the names of files and subdirectories in the specified 
-- path. The table is not sorted in any way; the order is undefined.
-- 
-- If the path passed to the function exists in the game and the save directory, 
-- it will list the files and directories from both places.
-- 
-- @function [parent = #filesystem] getDirectoryItems
-- @param #string dir The directory.
-- @return #table files A sequence with the names of all files and subdirectories as strings.

---
-- Returns a table with the names of files and subdirectories in the specified 
-- path. The table is not sorted in any way; the order is undefined.
-- 
-- If the path passed to the function exists in the game and the save directory, 
-- it will list the files and directories from both places.
-- 
-- @function [parent = #filesystem] getDirectoryItems
-- @param #string dir The directory.
-- @param #function callback A function which is called for each file and folder in the directory. The filename is passed to the function as an argument.
-- @return #table files A sequence with the names of all files and subdirectories as strings.

---
-- Gets the write directory name for your game. Note that this only returns the 
-- name of the folder to store your files in, not the full location.
-- 
-- @function [parent = #filesystem] getIdentity
-- @return #string name The identity that is used as write directory.

---
-- Gets the last modification time of a file.
-- 
-- @function [parent = #filesystem] getLastModified
-- @param #string filename The path and name to a file.
-- @return #number modtime The last modification time in seconds since the unix epoch or nil on failure.
-- @return #string errormsg The error message on failure.

---
-- Gets the full path to the designated save directory. This can be useful if you 
-- want to use the standard io library (or something else) to read or write in the 
-- save directory.
-- 
-- @function [parent = #filesystem] getSaveDirectory
-- @return #string dir The absolute path to the save directory.

---
-- Gets the size in bytes of a file.
-- 
-- @function [parent = #filesystem] getSize
-- @param #string filename The path and name to a file.
-- @return #number size The size in bytes of the file, or nil on failure.
-- @return #string errormsg The error message on failure.

---
-- Returns the path of the user's directory
-- 
-- @function [parent = #filesystem] getUserDirectory
-- @return #string path The path of the user's directory

---
-- Gets the current working directory.
-- 
-- @function [parent = #filesystem] getWorkingDirectory
-- @return #string cwd The current working directory.

---
-- Initializes love.filesystem, will be called internally, so should not be 
-- used explicitly.
-- 
-- @function [parent = #filesystem] init

---
-- Check whether something is a directory.
-- 
-- @function [parent = #filesystem] isDirectory
-- @param #string filename The path to a potential directory.
-- @return #boolean is_dir True if there is a directory with the specified name. False otherwise.

---
-- Check whether something is a file.
-- 
-- @function [parent = #filesystem] isFile
-- @param #string filename The path to a potential file.
-- @return #boolean is_file True if there is a file with the specified name. False otherwise.

---
-- Gets whether the game is in fused mode or not.
-- 
-- If a game is in fused mode, its save directory will be directly in the Appdata 
-- directory instead of Appdata/LOVE/. The game will also be able to load C Lua 
-- dynamic libraries which are located in the save directory.
-- 
-- A game is in fused mode if the source .love has been fused to the executable (see 
-- Game Distribution), or if "--fused" has been given as a command-line argument 
-- when starting the game.
-- 
-- @function [parent = #filesystem] isFused
-- @return #boolean fused True if the game is in fused mode, false otherwise.

---
-- Iterate over the lines in a file.
-- 
-- @function [parent = #filesystem] lines
-- @param #string name The name (and path) of the file
-- @return #function iterator A function that iterates over all the lines in the file

---
-- Load a lua file (but not run it)
-- 
-- @function [parent = #filesystem] load
-- @param #string name The name (and path) of the file
-- @return #function chunk The loaded chunk

---
-- Recursively creates a directory.
-- 
-- When called with "a/b" it creates both "a" and "a/b", if they don't exist already.
-- 
-- @function [parent = #filesystem] mkdir
-- @param #string name The directory to create.
-- @return #boolean ok True if the directory was created, false if not.

---
-- Mounts a zip file or folder in the game's save directory for reading.
-- 
-- @function [parent = #filesystem] mount
-- @param #string archive The folder or zip file in the game's save directory to mount.
-- @param #string mountpoint The new path the archive will be mounted to.
-- @return #boolean success True if the archive was successfully mounted, false otherwise.

---
-- Mounts a zip file or folder in the game's save directory for reading.
-- 
-- @function [parent = #filesystem] mount
-- @param #string archive The folder or zip file in the game's save directory to mount.
-- @param #string mountpoint The new path the archive will be mounted to.
-- @param #boolean appendToPath Whether the archive will be searched when reading a filepath before or after already-mounted archives. This includes the game's source and save directories.
-- @return #boolean success True if the archive was successfully mounted, false otherwise.

---
-- Creates a new File object. It needs to be opened before it can be accessed.
-- 
-- @function [parent = #filesystem] newFile
-- @param #string filename The filename of the file. (Note that ':' may not occur in a filename.)
-- @return #File file The new File object.

---
-- Creates a new File object. It needs to be opened before it can be accessed.
-- 
-- @function [parent = #filesystem] newFile
-- @param #string filename The filename of the file.
-- @param #FileMode mode The mode to open the file in.
-- @return #File file The new File object, or nil if an error occurred.
-- @return #string errorstr The error string if an error occurred.

---
-- Creates a new FileData object.
-- 
-- @function [parent = #filesystem] newFileData
-- @param #string contents The contents of the file.
-- @param #string name The name of the file.
-- @param #FileDecoder decoder The method to use when decoding the contents.
-- @return #FileData data Your new FileData.

---
-- Creates a new FileData object.
-- 
-- @function [parent = #filesystem] newFileData
-- @param #string filepath Path to the file.
-- @return #FileData data The new FileData, or nil if an error occurred.
-- @return #string err The error string, if an error occurred.

---
-- Read the contents of a file
-- 
-- @function [parent = #filesystem] read
-- @param #string name The name (and path) of the file
-- @param #number size How many bytes to read
-- @return #string contents The file contents
-- @return #number size How many bytes have been read

---
-- Removes a file or empty directory.
-- 
-- @function [parent = #filesystem] remove
-- @param #string name The file or directory to remove.
-- @return #boolean ok True if the file/directory was removed, false otherwise.

---
-- Sets the write directory for your game. Note that you can only set the name of 
-- the folder to store your files in, not the location.
-- 
-- @function [parent = #filesystem] setIdentity
-- @param #string name The new identity that will be used as write directory

---
-- Sets the write directory for your game. Note that you can only set the name of 
-- the folder to store your files in, not the location.
-- 
-- @function [parent = #filesystem] setIdentity
-- @param #string name The new identity that will be used as write directory
-- @param #boolean appendToPath Whether the identity directory will be searched when reading a filepath before or after the game's source directory and any archives currently mounted with love.filesystem.mount.

---
-- Sets the source of the game, where the code is present. This function can only 
-- be called once, and is normally automatically done by LÖVE.
-- 
-- @function [parent = #filesystem] setSource
-- @param #string path Absolute path to the game's source folder.

---
-- Unmounts a zip file or folder previously mounted for reading with love.filesystem.mount.
-- 
-- @function [parent = #filesystem] unmount
-- @param #string archive The folder or zip file in the game's save directory which is currently mounted.
-- @return #boolean success True if the archive was successfully unmounted, false otherwise.

---
-- Write data to a file in the save directory. If the file existed already, it will 
-- be completely replaced by the new contents.
-- 
-- @function [parent = #filesystem] write
-- @param #string name The name (and path) of the file.
-- @param #string data The string data to write to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success If the operation was successful.

---
-- Write data to a file in the save directory. If the file existed already, it will 
-- be completely replaced by the new contents.
-- 
-- @function [parent = #filesystem] write
-- @param #string name The name (and path) of the file.
-- @param #Data data The Data object to write to the file.
-- @param #number size How many bytes to write.
-- @return #boolean success If the operation was successful.


return nil
