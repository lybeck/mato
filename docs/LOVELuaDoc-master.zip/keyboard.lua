---
-- Provides an interface to the user's keyboard.
-- 
-- @module keyboard
--

---
-- Returns the delay and interval of key repeating.
-- 
-- @function [parent = #keyboard] getKeyRepeat
-- @return #number delay The amount of time before repeating the key (in seconds)
-- @return #number interval The amount of time between repeats (in seconds)

---
-- Gets whether key repeat is enabled.
-- 
-- @function [parent = #keyboard] hasKeyRepeat
-- @return #boolean enabled Whether key repeat is enabled.

---
-- Gets whether text input events are enabled.
-- 
-- @function [parent = #keyboard] hasTextInput
-- @return #boolean enabled Whether text input events are enabled.

---
-- Checks whether a certain key is down. Not to be confused with love.keypressed 
-- or love.keyreleased.
-- 
-- @function [parent = #keyboard] isDown
-- @param #KeyConstant key The key to check.
-- @return #boolean down True if the key is down, false if not.

---
-- Checks whether a certain key is down. Not to be confused with love.keypressed 
-- or love.keyreleased.
-- 
-- @function [parent = #keyboard] isDown
-- @param #KeyConstant keyN A key to check.
-- @return #boolean anyDown True if any supplied key is down, false if not.

---
-- Enables or disables key repeat. It is disabled by default.
-- 
-- @function [parent = #keyboard] setKeyRepeat
-- @param #boolean enable Whether repeat keypress events should be enabled when a key is held down.

---
-- Enables or disables key repeat. It is disabled by default.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #keyboard] setKeyRepeat
-- @param #number delay The amount of time before repeating the key (in seconds). 0 disables key repeat.
-- @param #number interval The amount of time between repeats (in seconds)

---
-- Enables or disables text input events. It is enabled by default.
-- 
-- @function [parent = #keyboard] setTextInput
-- @param #boolean enable Whether text input events should be enabled.


return nil
