---
-- Provides an interface for modifying and retrieving information about the 
-- program's window.
-- 
-- Dansk – Deutsch – English – Español – Français – Indonesia – Italiano – 
-- Lietuviškai – Magyar – Nederlands – Polski – Português – Română – Slovenský – 
-- Suomi – Svenska – Türkçe – Česky – Ελληνικά – Български – Русский – Српски – 
-- Українська – עברית – ไทย – 日本語 – 正體中文 – 简体中文 – Tiếng Việt – 한국어 More info
-- 
-- @module window
--

---
-- Gets the width and height of the desktop.
-- 
-- @function [parent = #window] getDesktopDimensions
-- @param #number display The index of the display, if multiple monitors are available.
-- @return #number width The width of the desktop.
-- @return #number height The height of the desktop.

---
-- Gets the width and height of the window.
-- 
-- @function [parent = #window] getDimensions
-- @return #number width The width of the window.
-- @return #number height The height of the window.

---
-- Gets the number of connected monitors.
-- 
-- @function [parent = #window] getDisplayCount
-- @return #number count The number of currently connected displays.

---
-- Gets the name of a display.
-- 
-- @function [parent = #window] getDisplayName
-- @param #number displayindex The index of the display to get the name of.
-- @return #string name The name of the specified display.

---
-- Gets whether the window is fullscreen.
-- 
-- @function [parent = #window] getFullscreen
-- @return #boolean fullscreen True if the window is fullscreen, false otherwise.
-- @return #FullscreenType fstype The type of fullscreen mode used.

---
-- Gets a list of supported fullscreen modes.
-- 
-- @function [parent = #window] getFullscreenModes
-- @param #number display The index of the display, if multiple monitors are available.
-- @return #table modes A table of width/height pairs. (Note that this may not be in order.)

---
-- Gets the height of the window.
-- 
-- @function [parent = #window] getHeight
-- @return #number height The height of the window.

---
-- Gets the window icon.
-- 
-- @function [parent = #window] getIcon
-- @return #ImageData imagedata The window icon imagedata, or nil if no icon has been set with love.window.setIcon.

---
-- Gets the display mode and properties of the window.
-- 
-- @function [parent = #window] getMode
-- @return #number width Window width.
-- @return #number height Window height.
-- @return #table flags Table with the window properties: boolean fullscreen Fullscreen (true), or windowed (false). FullscreenType fullscreentype The type of fullscreen mode used. boolean vsync True if the graphics framerate is synchronized with the monitor's refresh rate, false otherwise. number fsaa The number of antialiasing samples used (0 if FSAA is disabled.) boolean resizable True if the window is resizable in windowed mode, false otherwise. boolean borderless True if the window is borderless in windowed mode, false otherwise. boolean centered True if the window is centered in windowed mode, false otherwise. number display The index of the display the window is currently in, if multiple monitors are available. number minwidth The minimum width of the window, if it's resizable. number minheight The minimum height of the window, if it's resizable. boolean highdpi True if high-dpi mode is allowed on Retina displays in OS X. Does nothing on non-Retina displays. Added in 0.9.1. boolean srgb True if sRGB gamma correction is applied when drawing to the screen. Added in 0.9.1. number refreshrate The refresh rate of the screen's current display mode, in Hz. May be 0 if the value can't be determined. Added in 0.9.2. number x The x-coordinate of the window's position in its current display. Added in 0.9.2. number y The y-coordinate of the window's position in its current display. Added in 0.9.2.

---
-- Gets the scale factor associated with the window. In Mac OS X with the window 
-- in a retina screen and the highdpi window flag enabled this will be 2.0, otherwise 
-- it will be 1.0.
-- 
-- The scale factor is used to display graphics at a size the user is expecting, 
-- rather than the size of the pixels. On retina displays with the highdpi window 
-- flag enabled, the pixels in the window are 2x smaller than the scale of the normal 
-- content on the screen, so love.window.getPixelScale will return 2.
-- 
-- @function [parent = #window] getPixelScale
-- @return #number scale The pixel scale factor associated with the window.

---
-- Gets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the display it's currently 
-- in.
-- 
-- @function [parent = #window] getPosition
-- @return #number x The x-coordinate of the window's position.
-- @return #number y The y-coordinate of the window's position.
-- @return #number display The index of the display that the window is in.

---
-- Gets the window title.
-- 
-- @function [parent = #window] getTitle
-- @return #string title The current window title.

---
-- Gets the width of the window.
-- 
-- @function [parent = #window] getWidth
-- @return #number width The width of the window.

---
-- Checks if the game window has keyboard focus.
-- 
-- @function [parent = #window] hasFocus
-- @return #boolean focus True if the window has the focus or false if not.

---
-- Checks if the game window has mouse focus.
-- 
-- @function [parent = #window] hasMouseFocus
-- @return #boolean focus True if the window has mouse focus or false if not.

---
-- Checks if the window has been created.
-- 
-- @function [parent = #window] isCreated
-- @return #boolean created True if the window has been created, false otherwise.

---
-- Checks if the game window is visible.
-- 
-- The window is considered visible if it's not minimized and the program isn't 
-- hidden.
-- 
-- @function [parent = #window] isVisible
-- @return #boolean visible True if the window is visible or false if not.

---
-- Minimizes the window to the system's task bar / dock.
-- 
-- @function [parent = #window] minimize

---
-- Enters or exits fullscreen. The display to use when entering fullscreen is 
-- chosen based on which display the window is currently in, if multiple monitors 
-- are connected.
-- 
-- @function [parent = #window] setFullscreen
-- @param #boolean fullscreen Whether to enter or exit fullscreen mode.
-- @return #boolean success True if successful, false otherwise.

---
-- Enters or exits fullscreen. The display to use when entering fullscreen is 
-- chosen based on which display the window is currently in, if multiple monitors 
-- are connected.
-- 
-- @function [parent = #window] setFullscreen
-- @param #boolean fullscreen Whether to enter or exit fullscreen mode.
-- @param #FullscreenType fstype The type of fullscreen mode to use.
-- @return #boolean success True if successful, false otherwise.

---
-- Sets the window icon until the game is quit. Not all operating systems support 
-- very large icon images.
-- 
-- @function [parent = #window] setIcon
-- @param #ImageData imagedata The window icon image.
-- @return #boolean success Whether the icon has been set successfully.

---
-- Sets the display mode and properties of the window.
-- 
-- If width or height is 0, setMode will use the width and height of the desktop.
-- 
-- Changing the display mode may have side effects: for example, canvases will 
-- be cleared and values sent to shaders with Shader:send will be erased. Make 
-- sure to save the contents of Canvases beforehand or re-draw to them afterward 
-- if you need to.
-- 
-- @function [parent = #window] setMode
-- @param #number width Display width.
-- @param #number height Display height.
-- @param #table flags The flags table with the options: boolean fullscreen (false) Fullscreen (true), or windowed (false). FullscreenType fullscreentype ("normal") The type of fullscreen to use. boolean vsync (true) True if LÖVE should wait for vsync, false otherwise. number fsaa (0) The number of antialiasing samples. boolean resizable (false) True if the window should be resizable in windowed mode, false otherwise. boolean borderless (false) True if the window should be borderless in windowed mode, false otherwise. boolean centered (true) True if the window should be centered in windowed mode, false otherwise. number display (1) The index of the display to show the window in, if multiple monitors are available. number minwidth (1) The minimum width of the window, if it's resizable. Cannot be less than 1. number minheight (1) The minimum height of the window, if it's resizable. Cannot be less than 1. boolean highdpi (false) True if high-dpi mode should be used on Retina displays in OS X. Does nothing on non-Retina displays. Added in 0.9.1. boolean srgb (false) True if sRGB gamma correction should be applied when drawing to the screen. Added in 0.9.1. number x (nil) The x-coordinate of the window's position in the specified display. Added in 0.9.2. number y (nil) The y-coordinate of the window's position in the specified display. Added in 0.9.2.
-- @return #boolean success True if successful, false otherwise.

---
-- Sets the position of the window on the screen.
-- 
-- The window position is in the coordinate space of the specified display.
-- 
-- @function [parent = #window] setPosition
-- @param #number x The x-coordinate of the window's position.
-- @param #number y The y-coordinate of the window's position.
-- @param #number display The index of the display that the new window position is relative to.

---
-- Sets the window title.
-- 
-- @function [parent = #window] setTitle
-- @param #string title The new window title.

---
-- Displays a message box dialog above the love window. The message box contains 
-- a title, optional text, and buttons.
-- 
-- @function [parent = #window] showMessageBox
-- @param #string title The title of the message box.
-- @param #string message The text inside the message box.
-- @param #MessageBoxType type The type of the message box.
-- @param #boolean attachtowindow Whether the message box should be attached to the love window or free-floating.
-- @return #boolean success Whether the message box was successfully displayed.

---
-- Displays a message box dialog above the love window. The message box contains 
-- a title, optional text, and buttons.
-- 
-- @function [parent = #window] showMessageBox
-- @param #string title The title of the message box.
-- @param #string message The text inside the message box.
-- @param #table buttonlist A table containing a list of button names to show. The table can also contain the fields enterbutton and escapebutton, which should be the index of the default button to use when the user presses 'enter' or 'escape', respectively.
-- @param #MessageBoxType type The type of the message box.
-- @param #boolean attachtowindow Whether the message box should be attached to the love window or free-floating.
-- @return #number pressedbutton The index of the button pressed by the user. May be 0 if the message box dialog was closed without pressing a button.


return nil
