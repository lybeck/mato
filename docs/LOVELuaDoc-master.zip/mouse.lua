---
-- Provides an interface to the user's mouse.
-- 
-- @module mouse
--

---
-- Gets the current Cursor.
-- 
-- @function [parent = #mouse] getCursor
-- @return #Cursor cursor The current cursor, or nil if no cursor is set.

---
-- Returns the current position of the mouse.
-- 
-- @function [parent = #mouse] getPosition
-- @return #number x The position of the mouse along the x-axis.
-- @return #number y The position of the mouse along the y-axis.

---
-- Gets a Cursor object representing a system-native hardware cursor.
-- 
-- Hardware cursors are framerate-independent and work the same way as normal 
-- operating system cursors. Unlike drawing an image at the mouse's current coordinates, 
-- hardware cursors never have visible lag between when the mouse is moved and 
-- when the cursor position updates, even at low framerates.
-- 
-- @function [parent = #mouse] getSystemCursor
-- @param #CursorType ctype The type of system cursor to get.
-- @return #Cursor cursor The Cursor object representing the system cursor type.

---
-- Returns the current x-position of the mouse.
-- 
-- @function [parent = #mouse] getX
-- @return #number x The position of the mouse along the x-axis.

---
-- Returns the current y-position of the mouse.
-- 
-- @function [parent = #mouse] getY
-- @return #number y The position of the mouse along the y-axis.

---
-- Checks whether a certain mouse button is down. This function does not detect 
-- mousewheel scrolling; you must use the love.mousepressed callback for that.
-- 
-- @function [parent = #mouse] isDown
-- @param #MouseConstant button The button to check.
-- @return #boolean down True if the specified button is down.

---
-- Checks whether a certain mouse button is down. This function does not detect 
-- mousewheel scrolling; you must use the love.mousepressed callback for that.
-- 
-- @function [parent = #mouse] isDown
-- @param #MouseConstant buttonN A button to check.
-- @return #boolean anyDown True if any specified button is down, false otherwise.

---
-- Checks if the mouse is grabbed.
-- 
-- @function [parent = #mouse] isGrabbed
-- @return #boolean grabbed True if the cursor is grabbed, false if it is not.

---
-- Checks if the cursor is visible.
-- 
-- @function [parent = #mouse] isVisible
-- @return #boolean visible True if the cursor to visible, false if the cursor is hidden.

---
-- Creates a new hardware Cursor object from an image file or ImageData.
-- 
-- Hardware cursors are framerate-independent and work the same way as normal 
-- operating system cursors. Unlike drawing an image at the mouse's current coordinates, 
-- hardware cursors never have visible lag between when the mouse is moved and 
-- when the cursor position updates, even at low framerates.
-- 
-- The hot spot is the point the operating system uses to determine what was clicked 
-- and at what position the mouse cursor is. For example, the normal arrow pointer 
-- normally has its hot spot at the top left of the image, but a crosshair cursor 
-- might have it in the middle.
-- 
-- 
-- 
-- @function [parent = #mouse] newCursor
-- @param #ImageData imageData The ImageData to use for the new Cursor.
-- @param #number hotx The x-coordinate in the ImageData of the cursor's hot spot.
-- @param #number hoty The y-coordinate in the ImageData of the cursor's hot spot.
-- @return #Cursor cursor The new Cursor object.

---
-- Creates a new hardware Cursor object from an image file or ImageData.
-- 
-- Hardware cursors are framerate-independent and work the same way as normal 
-- operating system cursors. Unlike drawing an image at the mouse's current coordinates, 
-- hardware cursors never have visible lag between when the mouse is moved and 
-- when the cursor position updates, even at low framerates.
-- 
-- The hot spot is the point the operating system uses to determine what was clicked 
-- and at what position the mouse cursor is. For example, the normal arrow pointer 
-- normally has its hot spot at the top left of the image, but a crosshair cursor 
-- might have it in the middle.
-- 
-- 
-- 
-- @function [parent = #mouse] newCursor
-- @param #string filename Path to the image to use for the new Cursor.
-- @param #number hotx The x-coordinate in the image of the cursor's hot spot.
-- @param #number hoty The y-coordinate in the image of the cursor's hot spot.
-- @return #Cursor cursor The new Cursor object.

---
-- Creates a new hardware Cursor object from an image file or ImageData.
-- 
-- Hardware cursors are framerate-independent and work the same way as normal 
-- operating system cursors. Unlike drawing an image at the mouse's current coordinates, 
-- hardware cursors never have visible lag between when the mouse is moved and 
-- when the cursor position updates, even at low framerates.
-- 
-- The hot spot is the point the operating system uses to determine what was clicked 
-- and at what position the mouse cursor is. For example, the normal arrow pointer 
-- normally has its hot spot at the top left of the image, but a crosshair cursor 
-- might have it in the middle.
-- 
-- 
-- 
-- @function [parent = #mouse] newCursor
-- @param #FileData fileData Data representing the image to use for the new Cursor.
-- @param #number hotx The x-coordinate in the image of the cursor's hot spot.
-- @param #number hoty The y-coordinate in the image of the cursor's hot spot.
-- @return #Cursor cursor The new Cursor object.

---
-- Sets the current mouse cursor.
-- 
-- @function [parent = #mouse] setCursor
-- @param #Cursor cursor The Cursor object to use as the current mouse cursor.

---
-- Sets the current mouse cursor.
-- 
-- @function [parent = #mouse] setCursor

---
-- Grabs the mouse and confines it to the window.
-- 
-- @function [parent = #mouse] setGrab
-- @param #boolean grab True to confine the mouse, false to let it leave the window.

---
-- Grabs the mouse and confines it to the window.
-- 
-- @function [parent = #mouse] setGrabbed
-- @param #boolean grab True to confine the mouse, false to let it leave the window.

---
-- Sets the current position of the mouse.
-- 
-- @function [parent = #mouse] setPosition
-- @param #number x The new position of the mouse along the x-axis.
-- @param #number y The new position of the mouse along the y-axis.

---
-- Sets the current visibility of the cursor.
-- 
-- @function [parent = #mouse] setVisible
-- @param #boolean visible True to set the cursor to visible, false to hide the cursor.

---
-- Sets the current X position of the mouse.
-- 
-- @function [parent = #mouse] setX
-- @param #number x The new position of the mouse along the x-axis.

---
-- Sets the current Y position of the mouse.
-- 
-- @function [parent = #mouse] setY
-- @param #number y The new position of the mouse along the y-axis.


return nil
