---
-- Allows you to work with fonts.
-- 
-- Dansk – Deutsch – English – Español – Français – Indonesia – Italiano – 
-- Lietuviškai – Magyar – Nederlands – Polski – Português – Română – Slovenský – 
-- Suomi – Svenska – Türkçe – Česky – Ελληνικά – Български – Русский – Српски – 
-- Українська – עברית – ไทย – 日本語 – 正體中文 – 简体中文 – Tiếng Việt – 한국어 More info
-- 
-- @module font
--

---
-- Creates a new FontData.
-- 
-- @function [parent = #font] newFontData
-- @param #Rasterizer rasterizer The Rasterizer containing the font.
-- @return #FontData fontData The FontData.

---
-- Creates a new GlyphData.
-- 
-- @function [parent = #font] newGlyphData
-- @param #Rasterizer rasterizer The Rasterizer containing the font.
-- @param #number glyph The character code of the glyph.
-- @return #GlyphData glyphData The GlyphData.

---
-- Creates a new Rasterizer.
-- 
-- @function [parent = #font] newRasterizer
-- @param #ImageData imageData The image data containing the drawable pictures of font glyphs.
-- @param #string glyphs The sequence of glyphs in the ImageData.
-- @return #Rasterizer rasterizer The rasterizer.


return nil
