---
-- Provides an interface to output sound to the user's speakers.
-- 
-- Dansk – Deutsch – English – Español – Français – Indonesia – Italiano – 
-- Lietuviškai – Magyar – Nederlands – Polski – Português – Română – Slovenský – 
-- Suomi – Svenska – Türkçe – Česky – Ελληνικά – Български – Русский – Српски – 
-- Українська – עברית – ไทย – 日本語 – 正體中文 – 简体中文 – Tiếng Việt – 한국어 More info
-- 
-- @module audio
--

---
-- Returns the distance attenuation model.
-- 
-- @function [parent = #audio] getDistanceModel
-- @return #DistanceModel model The current distance model.

---
-- Gets the current number of simultaneously playing sources.
-- 
-- @function [parent = #audio] getNumSources
-- @return #number numSources The current number of simultaneously playing sources.

---
-- Returns the orientation of the listener.
-- 
-- @function [parent = #audio] getOrientation
-- @return #number fx, Forward vector of the listener orientation.
-- @return #number ux, Up vector of the listener orientation.

---
-- Returns the position of the listener. Please note that positional audio only 
-- works for mono (i.e. non-stereo) sources.
-- 
-- @function [parent = #audio] getPosition
-- @return #number x The X position of the listener.
-- @return #number y The Y position of the listener.
-- @return #number z The Z position of the listener.

---
-- Gets the current number of simultaneously playing sources.
-- 
-- @function [parent = #audio] getSourceCount
-- @return #number numSources The current number of simultaneously playing sources.

---
-- Returns the velocity of the listener.
-- 
-- @function [parent = #audio] getVelocity
-- @return #number x The X velocity of the listener.
-- @return #number y The Y velocity of the listener.
-- @return #number z The Z velocity of the listener.

---
-- Returns the master volume.
-- 
-- @function [parent = #audio] getVolume
-- @return #number volume The current master volume

---
-- Creates a new Source from a filepath, File, Decoder or SoundData. Sources created 
-- from SoundData are always static.
-- 
-- @function [parent = #audio] newSource
-- @param #string filename The filepath to the audio file.
-- @param #SourceType type Streaming or static source.
-- @return #Source source A new Source that can play the specified audio.

---
-- Creates a new Source from a filepath, File, Decoder or SoundData. Sources created 
-- from SoundData are always static.
-- 
-- @function [parent = #audio] newSource
-- @param #File file A File pointing to an audio file.
-- @param #SourceType type Streaming or static source.
-- @return #Source source A new Source that can play the specified audio.

---
-- Creates a new Source from a filepath, File, Decoder or SoundData. Sources created 
-- from SoundData are always static.
-- 
-- @function [parent = #audio] newSource
-- @param #Decoder decoder The Decoder to create a Source from.
-- @param #SourceType type Streaming or static source.
-- @return #Source source A new Source that can play the specified audio.

---
-- Creates a new Source from a filepath, File, Decoder or SoundData. Sources created 
-- from SoundData are always static.
-- 
-- @function [parent = #audio] newSource
-- @param #SoundData data The SoundData to create a Source from.
-- @return #Source source A new Source that can play the specified audio. The SourceType of the returned audio is "static".

---
-- Pauses all audio.
-- 
-- @function [parent = #audio] pause

---
-- Pauses all audio.
-- 
-- @function [parent = #audio] pause
-- @param #Source source The source on which to pause the playback

---
-- Plays the specified Source.
-- 
-- @function [parent = #audio] play
-- @param #Source source The Source to play.

---
-- Resumes all audio.
-- 
-- @function [parent = #audio] resume

---
-- Resumes all audio.
-- 
-- @function [parent = #audio] resume
-- @param #Source source The source on which to resume the playback.

---
-- Rewinds all playing audio.
-- 
-- @function [parent = #audio] rewind

---
-- Rewinds all playing audio.
-- 
-- @function [parent = #audio] rewind
-- @param #Source source The source to rewind.

---
-- Sets the distance attenuation model.
-- 
-- @function [parent = #audio] setDistanceModel
-- @param #DistanceModel model The new distance model.

---
-- Sets the orientation of the listener.
-- 
-- @function [parent = #audio] setOrientation
-- @param #number fx, Forward vector of the listener orientation.
-- @param #number ux, Up vector of the listener orientation.

---
-- Sets the position of the listener, which determines how sounds play.
-- 
-- @function [parent = #audio] setPosition
-- @param #number x The x position of the listener.
-- @param #number y The y position of the listener.
-- @param #number z The z position of the listener.

---
-- Sets the velocity of the listener.
-- 
-- @function [parent = #audio] setVelocity
-- @param #number x The X velocity of the listener.
-- @param #number y The Y velocity of the listener.
-- @param #number z The Z velocity of the listener.

---
-- Sets the master volume.
-- 
-- @function [parent = #audio] setVolume
-- @param #number volume 1.0f is max and 0.0f is off.

---
-- Stops currently played sources.
-- 
-- @function [parent = #audio] stop

---
-- Stops currently played sources.
-- 
-- @function [parent = #audio] stop
-- @param #Source source The source on which to stop the playback.


return nil
