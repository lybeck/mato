---
-- Provides an interface to decode encoded image data.
-- 
-- @module image
--

---
-- Determines whether a file can be loaded as CompressedData.
-- 
-- @function [parent = #image] isCompressed
-- @param #string filename The filename of the potentially compressed image file.
-- @return #boolean compressed Whether the file can be loaded as CompressedData or not.

---
-- Determines whether a file can be loaded as CompressedData.
-- 
-- @function [parent = #image] isCompressed
-- @param #FileData fileData A FileData potentially containing a compressed image.
-- @return #boolean compressed Whether the FileData can be loaded as CompressedData or not.

---
-- Create a new CompressedData object from a compressed image file. LÖVE currently 
-- supports DDS files compressed with the DXT1, DXT5, and BC5 / 3Dc formats.
-- 
-- @function [parent = #image] newCompressedData
-- @param #string filename The filename of the compressed image file.
-- @return #CompressedData compressedData The new CompressedData object.

---
-- Create a new CompressedData object from a compressed image file. LÖVE currently 
-- supports DDS files compressed with the DXT1, DXT5, and BC5 / 3Dc formats.
-- 
-- @function [parent = #image] newCompressedData
-- @param #FileData fileData A FileData containing a compressed image.
-- @return #CompressedData compressedData The new CompressedData object.

---
-- Encodes ImageData.
-- 
-- @function [parent = #image] newEncodedImageData
-- @param #ImageData imageData The raw ImageData to encode.
-- @param #ImageFormat format The format to encode the image in.
-- @return #Data data The encoded image data.

---
-- Creates a new ImageData object.
-- 
-- @function [parent = #image] newImageData
-- @param #number width The width of the ImageData.
-- @param #number height The height of the ImageData.
-- @return #ImageData imageData The new blank ImageData object. Each pixel's color values, (including the alpha values!) will be set to zero.

---
-- Creates a new ImageData object.
-- 
-- @function [parent = #image] newImageData
-- @param #string filename The filename of the image file.
-- @return #ImageData imageData The new ImageData object.

---
-- Creates a new ImageData object.
-- 
-- @function [parent = #image] newImageData
-- @param #FileData filedata The encoded file data to decode into image data.
-- @return #ImageData imageData The new ImageData object.


return nil
