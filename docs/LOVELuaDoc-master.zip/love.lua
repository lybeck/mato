---
-- When beginning to write games using LÖVE, the most important parts of the API 
-- are the callbacks: love.load to do one-time setup of your game, love.update 
-- which is used to manage your game's state frame-to-frame, and love.draw which 
-- is used to render the game state onto the screen.
-- 
-- More interactive games will override additional callbacks in order to handle 
-- input from the user, and other aspects of a full-featured game.
-- 
-- LÖVE provides default placeholders for these callbacks, which you can override 
-- inside your own code, simply by specifying their fully qualified name:
-- 
-- @module love
--

---
-- Provides an interface to output sound to the user's speakers.
-- @field [parent = #love] audio#audio audio
--

---
-- Manages events, like keypresses.
-- @field [parent = #love] event#event event
--

---
-- Provides an interface to the user's filesystem.
-- @field [parent = #love] filesystem#filesystem filesystem
--

---
-- Allows you to work with fonts. 0.7.0
-- @field [parent = #love] font#font font
--

---
-- Drawing of shapes and images, management of screen geometry.
-- @field [parent = #love] graphics#graphics graphics
--

---
-- Provides an interface to decode encoded image data.
-- @field [parent = #love] image#image image
--

---
-- Provides an interface to connected joysticks.
-- @field [parent = #love] joystick#joystick joystick
--

---
-- Provides an interface to the user's keyboard.
-- @field [parent = #love] keyboard#keyboard keyboard
--

---
-- Provides system-independent mathematical functions. 0.9.0
-- @field [parent = #love] math#math math
--

---
-- Provides an interface to the user's mouse.
-- @field [parent = #love] mouse#mouse mouse
--

---
-- Can simulate 2D rigid body physics in a realistic manner.
-- @field [parent = #love] physics#physics physics
--

---
-- This module is responsible for decoding sound files.
-- @field [parent = #love] sound#sound sound
--

---
-- Provides access to information about the user's system. 0.9.0
-- @field [parent = #love] system#system system
--

---
-- Allows you to work with threads. 0.7.0
-- @field [parent = #love] thread#thread thread
--

---
-- Provides an interface to your system's clock.
-- @field [parent = #love] timer#timer timer
--

---
-- Provides an interface for the program's window. 0.9.0
-- @field [parent = #love] window#window window
--

---
-- Gets the current running version of LÖVE.
-- 
-- @function [parent = #love] getVersion
-- @return #number major The major version of LÖVE, i.e. 0 for version 0.9.1.
-- @return #number minor The minor version of LÖVE, i.e. 9 for version 0.9.1.
-- @return #number revision The revision version of LÖVE, i.e. 1 for version 0.9.1.
-- @return #string codename The codename of the current version.

---
-- Callback function used to draw on the screen every frame.
-- 
-- @function [parent = #love] draw

---
-- The error handler, used to display error messages. In the source can be found 
-- in /src/scripts/boot.lua
-- 
-- @function [parent = #love] errhand
-- @param #string msg The error message.

---
-- Callback function triggered when window receives or loses focus.
-- 
-- @function [parent = #love] focus
-- @param #boolean f Window focus

---
-- Callback function triggered when a key is pressed.
-- 
-- @function [parent = #love] keypressed
-- @param #KeyConstant key Character of the key pressed.
-- @param #boolean isrepeat Whether this keypress event is a repeat. The delay between key repeats depends on the user's system settings.

---
-- Callback function triggered when a key is pressed.
-- 
-- Removed in LÖVE 0.9.0 Unicode text input is now handled separately via love.textinput.
-- 
-- @function [parent = #love] keypressed
-- @param #KeyConstant key Character of the key pressed.
-- @param #number unicode The unicode number of the key pressed.

---
-- Callback function triggered when a key is released.
-- 
-- Unlike love.keypressed, love.keyreleased does not have an unicode argument 
-- because those characters are only generated when keys are pressed.
-- 
-- @function [parent = #love] keyreleased
-- @param #KeyConstant key Character of the key released.

---
-- This function is called exactly once at the beginning of the game.
-- 
-- @function [parent = #love] load
-- @param #table arg Command line arguments given to the game.

---
-- Callback function triggered when window receives or loses mouse focus.
-- 
-- @function [parent = #love] mousefocus
-- @param #boolean f Window mouse focus

---
-- Callback function triggered when a mouse button is pressed.
-- 
-- @function [parent = #love] mousepressed
-- @param #number x Mouse x position.
-- @param #number y Mouse y position.
-- @param #MouseConstant button Mouse button pressed.

---
-- Callback function triggered when a mouse button is released.
-- 
-- @function [parent = #love] mousereleased
-- @param #number x Mouse x position.
-- @param #number y Mouse y position.
-- @param #MouseConstant button Mouse button released，except Mouse Wheel.

---
-- Callback function triggered when the game is closed.
-- 
-- @function [parent = #love] quit
-- @return #boolean r Abort quitting. If true, do not close the game.

---
-- Called when the window is resized, for example if the user resizes the window, 
-- or if love.window.setMode is called with an unsupported width or height in 
-- fullscreen and the window chooses the closest appropriate size.
-- 
-- @function [parent = #love] resize
-- @param #number w The new width, in pixels.
-- @param #number h The new height, in pixels.

---
-- The main function, containing the main loop. A sensible default is used when 
-- left out.
-- 
-- @function [parent = #love] run

---
-- Called when text has been entered by the user. For example if shift-2 is pressed 
-- on an American keyboard layout, the text "@" will be generated.
-- 
-- @function [parent = #love] textinput
-- @param #string text The UTF-8 encoded unicode text.

---
-- Callback function triggered when a Thread encounters an error.
-- 
-- @function [parent = #love] threaderror
-- @param #Thread thread The thread which produced the error.
-- @param #string errorstr The error message.

---
-- Callback function used to update the state of the game every frame.
-- 
-- @function [parent = #love] update
-- @param #number dt Time since the last update in seconds.

---
-- Callback function triggered when window is minimized/hidden or unminimized 
-- by the user.
-- 
-- @function [parent = #love] visible
-- @param #boolean v Window visibility.

---
-- Called when a Joystick's virtual gamepad axis is moved.
-- 
-- @function [parent = #love] gamepadaxis
-- @param #Joystick joystick The joystick object.
-- @param #GamepadAxis axis The virtual gamepad axis.
-- @param #number value The new axis value.

---
-- Called when a Joystick's virtual gamepad button is pressed.
-- 
-- @function [parent = #love] gamepadpressed
-- @param #Joystick joystick The joystick object.
-- @param #GamepadButton button The virtual gamepad button.

---
-- Called when a Joystick's virtual gamepad button is released.
-- 
-- @function [parent = #love] gamepadreleased
-- @param #Joystick joystick The joystick object.
-- @param #GamepadButton button The virtual gamepad button.

---
-- Called when a Joystick is connected.
-- 
-- @function [parent = #love] joystickadded
-- @param #Joystick joystick The newly connected Joystick object.

---
-- Called when a joystick axis moves.
-- 
-- @function [parent = #love] joystickaxis
-- @param #Joystick joystick The joystick object.
-- @param #number axis The axis number.
-- @param #number value The new axis value.

---
-- Called when a joystick hat direction changes.
-- 
-- @function [parent = #love] joystickhat
-- @param #Joystick joystick The joystick object.
-- @param #number hat The hat number.
-- @param #JoystickHat direction The new hat direction.

---
-- Called when a joystick button is pressed.
-- 
-- @function [parent = #love] joystickpressed
-- @param #Joystick joystick The joystick object.
-- @param #number button The button number.

---
-- Called when a joystick button is pressed.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #love] joystickpressed
-- @param #number joystick The joystick number.
-- @param #number button The button number.

---
-- Called when a joystick button is released.
-- 
-- @function [parent = #love] joystickreleased
-- @param #Joystick joystick The joystick object.
-- @param #number button The button number.

---
-- Called when a joystick button is released.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #love] joystickreleased
-- @param #number joystick The joystick number.
-- @param #number button The button number.

---
-- Called when a Joystick is disconnected.
-- 
-- @function [parent = #love] joystickremoved
-- @param #Joystick joystick The now-disconnected Joystick object.


return nil
