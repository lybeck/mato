---
-- The primary responsibility for the love.graphics module is the drawing of 
-- lines, shapes, text, Images and other Drawable objects onto the screen. Its 
-- secondary responsibilities include loading external files (including Images 
-- and Fonts) into memory, creating specialized objects (such as ParticleSystems 
-- or Canvases) and managing screen geometry.
-- 
-- LÖVE's coordinate system is rooted in the upper-left corner of the screen, 
-- which is at location (0, 0). The x axis is horizontal: larger values are further 
-- to the right. The y axis is vertical: larger values are further towards the bottom.
-- 
-- @module graphics
--

---
-- Draws a filled or unfilled arc at position (x, y). The arc is drawn from angle1 
-- to angle2 in radians. The segments parameter determines how many segments 
-- are used to draw the arc. The more segments, the smoother the edge.
-- 
-- @function [parent = #graphics] arc
-- @param #DrawMode mode How to draw the arc.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius Radius of the arc.
-- @param #number angle1 The angle at which the arc begins.
-- @param #number angle2 The angle at which the arc terminates.
-- @param #number segments The number of segments used for drawing the arc.

---
-- Draws a circle.
-- 
-- @function [parent = #graphics] circle
-- @param #DrawMode mode How to draw the circle.
-- @param #number x The position of the center along x-axis.
-- @param #number y The position of the center along y-axis.
-- @param #number radius The radius of the circle.
-- @param #number segments The number of segments used for drawing the circle.

---
-- Clears the screen to the background color and restores the default coordinate 
-- system.
-- 
-- This function is called automatically before love.draw in the default love.run 
-- function. See the example in love.run for a typical use of this function.
-- 
-- Note that the scissor area bounds the cleared region.
-- 
-- @function [parent = #graphics] clear

---
-- Draws a Drawable object (an Image, Canvas, SpriteBatch, ParticleSystem, 
-- or Mesh) on the screen with optional rotation, scaling and shearing.
-- 
-- Objects are drawn relative to their local coordinate system. The origin is 
-- by default located at the top left corner of Image and Canvas. All scaling, shearing, 
-- and rotation arguments transform the object relative to that point. Also, 
-- the position of the origin can be specified on the screen coordinate system.
-- 
-- It's possible to rotate an object about its center by offsetting the origin 
-- to the center. Angles must be given in radians for rotation. One can also use 
-- a negative scaling factor to flip about its centerline.
-- 
-- Note that the offsets are applied before rotation, scaling, or shearing; scaling 
-- and shearing are applied before rotation.
-- 
-- The right and bottom edges of the object are shifted at an angle defined by the 
-- shearing factors.
-- 
-- @function [parent = #graphics] draw
-- @param #Drawable drawable A drawable object.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).

---
-- Draws a Drawable object (an Image, Canvas, SpriteBatch, ParticleSystem, 
-- or Mesh) on the screen with optional rotation, scaling and shearing.
-- 
-- Objects are drawn relative to their local coordinate system. The origin is 
-- by default located at the top left corner of Image and Canvas. All scaling, shearing, 
-- and rotation arguments transform the object relative to that point. Also, 
-- the position of the origin can be specified on the screen coordinate system.
-- 
-- It's possible to rotate an object about its center by offsetting the origin 
-- to the center. Angles must be given in radians for rotation. One can also use 
-- a negative scaling factor to flip about its centerline.
-- 
-- Note that the offsets are applied before rotation, scaling, or shearing; scaling 
-- and shearing are applied before rotation.
-- 
-- The right and bottom edges of the object are shifted at an angle defined by the 
-- shearing factors.
-- 
-- @function [parent = #graphics] draw
-- @param #Image or An Image or Canvas to texture the Quad with.
-- @param #Quad quad The Quad to draw on screen.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shearing factor (x-axis).
-- @param #number ky Shearing factor (y-axis).

---
-- Draw a Quad with the specified Image on screen.
-- 
-- @function [parent = #graphics] drawq
-- @param #Image image An image to texture the quad with.
-- @param #Quad quad The quad to draw on screen.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).

---
-- Draw a Quad with the specified Image on screen.
-- 
-- @function [parent = #graphics] drawq
-- @param #Canvas canvas A canvas to texture the quad with.
-- @param #Quad quad The quad to draw on screen.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).

---
-- Draws lines between points.
-- 
-- @function [parent = #graphics] line
-- @param #number x1 The position of first point on the x-axis.
-- @param #number y1 The position of first point on the y-axis.
-- @param #number x2 The position of second point on the x-axis.
-- @param #number y2 The position of second point on the y-axis.
-- @param #number ... You can continue passing point positions to draw a polyline.

---
-- Draws lines between points.
-- 
-- @function [parent = #graphics] line
-- @param #table points A table of point positions, as described above.

---
-- Draws a point.
-- 
-- @function [parent = #graphics] point
-- @param #number x The position on the x-axis.
-- @param #number y The position on the y-axis.

---
-- Draw a polygon.
-- 
-- Following the mode argument, this function can accept multiple numeric arguments 
-- or a single table of numeric arguments. In either case the arguments are interpreted 
-- as alternating x and y coordinates of the polygon's vertices.
-- 
-- Note: when in fill mode, the polygon must be convex and simple or rendering artifacts 
-- may occur. love.math.triangulate and love.math.isConvex can be used in 0.9.0+.
-- 
-- @function [parent = #graphics] polygon
-- @param #DrawMode mode How to draw the polygon.
-- @param #number ... The vertices of the polygon.

---
-- Draw a polygon.
-- 
-- Following the mode argument, this function can accept multiple numeric arguments 
-- or a single table of numeric arguments. In either case the arguments are interpreted 
-- as alternating x and y coordinates of the polygon's vertices.
-- 
-- Note: when in fill mode, the polygon must be convex and simple or rendering artifacts 
-- may occur. love.math.triangulate and love.math.isConvex can be used in 0.9.0+.
-- 
-- @function [parent = #graphics] polygon
-- @param #DrawMode mode How to draw the polygon.
-- @param #table vertices The vertices of the polygon as a table.

---
-- Displays the results of drawing operations on the screen.
-- 
-- This function is used when writing your own love.run function. It presents 
-- all the results of your drawing operations on the screen. See the example in 
-- love.run for a typical use of this function.
-- 
-- @function [parent = #graphics] present

---
-- Draws text on screen. If no Font is set, one will be created and set (once) if needed.
-- 
-- As of LOVE 0.7.1, when using translation and scaling functions while drawing 
-- text, this function assumes the scale occurs first. If you don't script with 
-- this in mind, the text won't be in the right position, or possibly even on screen.
-- 
-- love.graphics.print and love.graphics.printf both suppport UTF-8 encoding. 
-- You'll also need a proper Font for special characters.
-- 
-- @function [parent = #graphics] print
-- @param #string text The text to draw.
-- @param #number x The position to draw the object (x-axis).
-- @param #number y The position to draw the object (y-axis).
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).

---
-- Draws formatted text, with word wrap and alignment.
-- 
-- See additional notes in love.graphics.print.
-- 
-- @function [parent = #graphics] printf
-- @param #string text A text string.
-- @param #number x The position on the x-axis.
-- @param #number y The position on the y-axis.
-- @param #number limit Wrap the line after this many horizontal pixels.
-- @param #AlignMode align The alignment.

---
-- Draws formatted text, with word wrap and alignment.
-- 
-- See additional notes in love.graphics.print.
-- 
-- @function [parent = #graphics] printf
-- @param #string text A text string.
-- @param #number x The position on the x-axis.
-- @param #number y The position on the y-axis.
-- @param #number limit Wrap the line after this many horizontal pixels.
-- @param #AlignMode align The alignment.
-- @param #number r Orientation (radians).
-- @param #number sx Scale factor (x-axis).
-- @param #number sy Scale factor (y-axis).
-- @param #number ox Origin offset (x-axis).
-- @param #number oy Origin offset (y-axis).
-- @param #number kx Shearing factor (x-axis).
-- @param #number ky Shearing factor (y-axis).

---
-- Draws a quadrilateral shape.
-- 
-- @function [parent = #graphics] quad
-- @param #DrawMode mode How to draw the quad.
-- @param #number x1 The position of the top left corner along x-axis.
-- @param #number y1 The position of the top left corner along y-axis.
-- @param #number x2 The position of the top right corner along x-axis.
-- @param #number y2 The position of the top right corner along y-axis.
-- @param #number x3 The position of the bottom right corner along x-axis.
-- @param #number y3 The position of the bottom right corner along y-axis.
-- @param #number x4 The position of the bottom left corner along x-axis.
-- @param #number y4 The position of the bottom left corner along y-axis.

---
-- Draws a rectangle.
-- 
-- @function [parent = #graphics] rectangle
-- @param #DrawMode mode How to draw the rectangle.
-- @param #number x The position of top-left corner along x-axis.
-- @param #number y The position of top-left corner along y-axis.
-- @param #number width Width of the rectangle.
-- @param #number height Height of the rectangle.

---
-- Draws a triangle.
-- 
-- @function [parent = #graphics] triangle
-- @param #DrawMode mode How to draw the triangle.
-- @param #number x1 The position of first point on the x-axis.
-- @param #number y1 The position of first point on the y-axis.
-- @param #number x2 The position of second point on the x-axis.
-- @param #number y2 The position of second point on the y-axis.
-- @param #number x3 The position of third point on the x-axis.
-- @param #number y3 The position of third point on the y-axis.

---
-- Creates a new Canvas object for offscreen rendering.
-- 
-- @function [parent = #graphics] newCanvas
-- @return #Canvas canvas A new Canvas with width/height equal to the window width/height.

---
-- Creates a new Canvas object for offscreen rendering.
-- 
-- @function [parent = #graphics] newCanvas
-- @param #number width The desired width of the Canvas.
-- @param #number height The desired height of the Canvas.
-- @return #Canvas canvas A new Canvas with specified width and height.

---
-- Creates a new Canvas object for offscreen rendering.
-- 
-- @function [parent = #graphics] newCanvas
-- @param #number width The desired width of the Canvas.
-- @param #number height The desired height of the Canvas.
-- @param #TextureFormat format The desired texture format of the Canvas.
-- @return #Canvas canvas A new Canvas with specified width and height.

---
-- Creates a new Canvas object for offscreen rendering.
-- 
-- @function [parent = #graphics] newCanvas
-- @param #number width The desired width of the Canvas.
-- @param #number height The desired height of the Canvas.
-- @param #TextureFormat format The desired texture format of the Canvas.
-- @param #number fsaa The desired number of antialiasing samples used when drawing to the Canvas.
-- @return #Canvas canvas A new Canvas with specified width and height.

---
-- Creates a new Font.
-- 
-- @function [parent = #graphics] newFont
-- @param #string filename The filepath to the font file.
-- @param #number size The size of the font in pixels.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font.
-- 
-- @function [parent = #graphics] newFont
-- @param #File file A File pointing to a font.
-- @param #number size The size of the font in pixels.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font.
-- 
-- @function [parent = #graphics] newFont
-- @param #Data data The encoded data to decode into a font.
-- @param #number size The size of the font in pixels.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font.
-- 
-- @function [parent = #graphics] newFont
-- @param #number size The size of the font in pixels.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new framebuffer object for offscreen rendering.
-- 
-- @function [parent = #graphics] newFramebuffer
-- @return #Framebuffer framebuffer A new framebuffer with width/height equal to the window width/height.

---
-- Creates a new framebuffer object for offscreen rendering.
-- 
-- @function [parent = #graphics] newFramebuffer
-- @param #number width The desired width of the framebuffer.
-- @param #number height The desired height of the framebuffer.
-- @return #Framebuffer framebuffer A new framebuffer with specified width and height.

---
-- Creates a new Image from a filepath, FileData or an ImageData.
-- 
-- @function [parent = #graphics] newImage
-- @param #string filename The filepath to the image file.
-- @return #Image image An Image object which can be drawn on screen.

---
-- Creates a new Image from a filepath, FileData or an ImageData.
-- 
-- @function [parent = #graphics] newImage
-- @param #ImageData imageData An ImageData object. The Image will use this ImageData to reload itself when love.window.setMode is called.
-- @return #Image image An Image object which can be drawn on screen.

---
-- Creates a new Image from a filepath, FileData or an ImageData.
-- 
-- @function [parent = #graphics] newImage
-- @param #CompressedData compressedData A CompressedData object. The Image will use this CompressedData to reload itself when love.window.setMode is called.
-- @return #Image image An Image object which can be drawn on screen.

---
-- Creates a new Image from a filepath, FileData or an ImageData.
-- 
-- @function [parent = #graphics] newImage
-- @param #string filename The filepath to the image file (or a FileData or ImageData or CompressedData object.)
-- @param #TextureFormat format The format to interpret the image's data as.
-- @return #Image image An Image object which can be drawn on screen.

---
-- Creates a new Font by loading a specifically formatted image. There can be up 
-- to 256 glyphs.
-- 
-- @function [parent = #graphics] newImageFont
-- @param #string filename The filepath to the image file.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font by loading a specifically formatted image. There can be up 
-- to 256 glyphs.
-- 
-- @function [parent = #graphics] newImageFont
-- @param #Data data The encoded data to decode into image data.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font by loading a specifically formatted image. There can be up 
-- to 256 glyphs.
-- 
-- @function [parent = #graphics] newImageFont
-- @param #ImageData imageData The ImageData object to create the font from.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Font by loading a specifically formatted image. There can be up 
-- to 256 glyphs.
-- 
-- @function [parent = #graphics] newImageFont
-- @param #Image image The Image object to create the font from.
-- @param #string glyphs A string of the characters in the image in order from left to right.
-- @return #Font font A Font object which can be used to draw text on screen.

---
-- Creates a new Mesh.
-- 
-- @function [parent = #graphics] newMesh
-- @param #table vertices The table filled with vertex information tables for each vertex as follows: number [1] The position of the vertex on the x-axis. number [2] The position of the vertex on the y-axis. number [3] The u texture coordinate. Texture coordinates are normally in the range of [0, 1], but can be greater or less (see WrapMode.) number [4] The v texture coordinate. Texture coordinates are normally in the range of [0, 1], but can be greater or less (see WrapMode.) number [5] (255) The red color component. number [6] (255) The green color component. number [7] (255) The blue color component. number [8] (255) The alpha color component.
-- @return #Mesh mesh The new mesh.

---
-- Creates a new Mesh.
-- 
-- @function [parent = #graphics] newMesh
-- @param #number vertexcount The total number of vertices the Mesh will use. Each vertex is initialized to {0,0, 0,0, 255,255,255,255}.
-- @param #Texture texture The Image or Canvas to use when drawing the Mesh. May be nil to use no texture.
-- @param #MeshDrawMode mode How the vertices are used when drawing. The default mode "fan" is sufficient for simple convex polygons.
-- @return #Mesh mesh The new mesh.

---
-- Creates a new ParticleSystem.
-- 
-- @function [parent = #graphics] newParticleSystem
-- @param #Image image The image to use.
-- @param #number buffer The max number of particles at the same time.
-- @return #ParticleSystem system A new ParticleSystem.

---
-- Creates a new ParticleSystem.
-- 
-- @function [parent = #graphics] newParticleSystem
-- @param #Texture texture The texture (Image or Canvas) to use.
-- @param #number buffer The max number of particles at the same time.
-- @return #ParticleSystem system A new ParticleSystem.

---
-- Creates a new PixelEffect object for hardware-accelerated pixel level effects.
-- 
-- A PixelEffect contains at least one function, named effect, which is the effect 
-- itself, but it can contain additional functions.
-- 
-- @function [parent = #graphics] newPixelEffect
-- @param #string code The pixel effect code.
-- @param #vec4 color The drawing color set with love.graphics.setColor.
-- @param #Image texture The texture of the image or canvas being drawn.
-- @param #vec2 texture_coords Coordinates of the pixel relative to the texture. The y-axis of canvases are inverted. Coordinates (1,1) would be the top right corner of the canvas.
-- @param #vec2 screen_coords Coordinates of the pixel on the screen. Pixel coordinates are not normalized (unlike texture coordinates)
-- @return #PixelEffect pixeleffect A PixelEffect object for use in drawing operations.
-- @return #vec4 output_color The color of the pixel.

---
-- Creates a new PixelEffect object for hardware-accelerated pixel level effects.
-- 
-- A PixelEffect contains at least one function, named effect, which is the effect 
-- itself, but it can contain additional functions.
-- 
-- @function [parent = #graphics] newPixelEffect
-- @param #string code The pixel effect code.
-- @param #vec4 color The drawing color set with love.graphics.setColor.
-- @param #Image texture The texture of the image or canvas being drawn.
-- @param #vec2 texture_coords Coordinates of the pixel relative to the texture. The y-axis of canvases are inverted. Coordinates (1,1) would be the top right corner of the canvas.
-- @param #vec2 screen_coords Coordinates of the pixel on the screen. Pixel coordinates are not normalized (unlike texture coordinates)
-- @return #PixelEffect pixeleffect A PixelEffect object for use in drawing operations.
-- @return #vec4 output_color The color of the pixel.

---
-- Creates a new Quad.
-- 
-- @function [parent = #graphics] newQuad
-- @param #number x The top-left position along the x-axis.
-- @param #number y The top-left position along the y-axis.
-- @param #number width The width of the Quad. (Must be greater than 0.)
-- @param #number height The height of the Quad. (Must be greater than 0.)
-- @param #number sw The reference width, the width of the Image. (Must be greater than 0.)
-- @param #number sh The reference height, the height of the Image. (Must be greater than 0.)
-- @return #Quad quad The new Quad.

---
-- Creates a screenshot and returns the image data.
-- 
-- @function [parent = #graphics] newScreenshot
-- @return #ImageData screenshot The image data of the screenshot.

---
-- Creates a screenshot and returns the image data.
-- 
-- @function [parent = #graphics] newScreenshot
-- @param #boolean copyAlpha Whether to include the screen's alpha channel in the ImageData. If false, the screenshot will be fully opaque.
-- @return #ImageData screenshot The image data of the screenshot.

---
-- 
-- 
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. 
-- A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Shaders are small programs which are run on the video card when drawing. Vertex 
-- shaders are run once for each vertex (for example, an image has 4 vertices - one 
-- at each corner. A Mesh might have many more.) Pixel shaders are run once for each 
-- pixel on the screen which the drawn object touches. Pixel shader code is executed 
-- after all the object's vertices have been processed by the vertex shader.
-- 
-- @function [parent = #graphics] newShader
-- @param #string code The pixel shader or vertex shader code, or a filename pointing to a file with the code.
-- @return #Shader shader A Shader object for use in drawing operations.

---
-- 
-- 
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. 
-- A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Shaders are small programs which are run on the video card when drawing. Vertex 
-- shaders are run once for each vertex (for example, an image has 4 vertices - one 
-- at each corner. A Mesh might have many more.) Pixel shaders are run once for each 
-- pixel on the screen which the drawn object touches. Pixel shader code is executed 
-- after all the object's vertices have been processed by the vertex shader.
-- 
-- @function [parent = #graphics] newShader
-- @param #string pixelcode The pixel shader code, or a filename pointing to a file with the code.
-- @param #string vertexcode The vertex shader code, or a filename pointing to a file with the code.
-- @param #vec4 color The drawing color set with love.graphics.setColor or the per-vertex Mesh color.
-- @param #Image texture The texture of the image or canvas being drawn.
-- @param #vec2 texture_coords Coordinates of the pixel relative to the texture. The y-axis of canvases are inverted. Coordinates (1,1) would be the top right corner of the canvas.
-- @param #vec2 screen_coords Coordinates of the pixel on the screen. Pixel coordinates are not normalized (unlike texture coordinates)
-- @param #mat4 transform_projection The transformation matrix affected by love.graphics.translate and friends combined with the orthographic projection matrix.
-- @param #vec4 vertex_position The raw un-transformed position of the current vertex.
-- @return #Shader shader A Shader object for use in drawing operations.
-- @return #vec4 output_color The color of the pixel.
-- @return #vec4 output_pos The final transformed position of the current vertex.

---
-- 
-- 
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. 
-- A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Shaders are small programs which are run on the video card when drawing. Vertex 
-- shaders are run once for each vertex (for example, an image has 4 vertices - one 
-- at each corner. A Mesh might have many more.) Pixel shaders are run once for each 
-- pixel on the screen which the drawn object touches. Pixel shader code is executed 
-- after all the object's vertices have been processed by the vertex shader.
-- 
-- @function [parent = #graphics] newShader
-- @param #string pixelcode The pixel shader code, or a filename pointing to a file with the code.
-- @param #string vertexcode The vertex shader code, or a filename pointing to a file with the code.
-- @param #vec4 color The drawing color set with love.graphics.setColor or the per-vertex Mesh color.
-- @param #Image texture The texture of the image or canvas being drawn.
-- @param #vec2 texture_coords Coordinates of the pixel relative to the texture. The y-axis of canvases are inverted. Coordinates (1,1) would be the top right corner of the canvas.
-- @param #vec2 screen_coords Coordinates of the pixel on the screen. Pixel coordinates are not normalized (unlike texture coordinates)
-- @param #mat4 transform_projection The transformation matrix affected by love.graphics.translate and friends combined with the orthographic projection matrix.
-- @param #vec4 vertex_position The raw un-transformed position of the current vertex.
-- @return #Shader shader A Shader object for use in drawing operations.
-- @return #vec4 output_color The color of the pixel.
-- @return #vec4 output_pos The final transformed position of the current vertex.

---
-- 
-- 
-- Creates a new Shader object for hardware-accelerated vertex and pixel effects. 
-- A Shader contains either vertex shader code, pixel shader code, or both.
-- 
-- Shaders are small programs which are run on the video card when drawing. Vertex 
-- shaders are run once for each vertex (for example, an image has 4 vertices - one 
-- at each corner. A Mesh might have many more.) Pixel shaders are run once for each 
-- pixel on the screen which the drawn object touches. Pixel shader code is executed 
-- after all the object's vertices have been processed by the vertex shader.
-- 
-- @function [parent = #graphics] newShader
-- @param #string pixelcode The pixel shader code, or a filename pointing to a file with the code.
-- @param #string vertexcode The vertex shader code, or a filename pointing to a file with the code.
-- @param #vec4 color The drawing color set with love.graphics.setColor or the per-vertex Mesh color.
-- @param #Image texture The texture of the image or canvas being drawn.
-- @param #vec2 texture_coords Coordinates of the pixel relative to the texture. The y-axis of canvases are inverted. Coordinates (1,1) would be the top right corner of the canvas.
-- @param #vec2 screen_coords Coordinates of the pixel on the screen. Pixel coordinates are not normalized (unlike texture coordinates)
-- @param #mat4 transform_projection The transformation matrix affected by love.graphics.translate and friends combined with the orthographic projection matrix.
-- @param #vec4 vertex_position The raw un-transformed position of the current vertex.
-- @return #Shader shader A Shader object for use in drawing operations.
-- @return #vec4 output_color The color of the pixel.
-- @return #vec4 output_pos The final transformed position of the current vertex.

---
-- Creates a new SpriteBatch object.
-- 
-- @function [parent = #graphics] newSpriteBatch
-- @param #Image image The Image to use for the sprites.
-- @param #number size The max number of sprites.
-- @return #SpriteBatch spriteBatch The new SpriteBatch.

---
-- Creates a new SpriteBatch object.
-- 
-- @function [parent = #graphics] newSpriteBatch
-- @param #Image image The Image to use for the sprites.
-- @param #number size The max number of sprites.
-- @param #SpriteBatchUsage usagehint The expected usage of the SpriteBatch.
-- @return #SpriteBatch spriteBatch The new SpriteBatch.

---
-- Creates a new SpriteBatch object.
-- 
-- @function [parent = #graphics] newSpriteBatch
-- @param #Texture texture The Image or Canvas to use for the sprites.
-- @param #number size The max number of sprites.
-- @param #SpriteBatchUsage usagehint The expected usage of the SpriteBatch.
-- @return #SpriteBatch spriteBatch The new SpriteBatch.

---
-- Creates a new stencil.
-- 
-- @function [parent = #graphics] newStencil
-- @param #function stencilFunction Function that draws the stencil.
-- @return #function myStencil Function that defines the new stencil.

---
-- Creates and sets a new Font.
-- 
-- @function [parent = #graphics] setNewFont
-- @param #number size The size of the font.
-- @return #Font font The new font.

---
-- Creates and sets a new Font.
-- 
-- @function [parent = #graphics] setNewFont
-- @param #string filename The path and name of the file with the font.
-- @param #number size The size of the font.
-- @return #Font font The new font.

---
-- Creates and sets a new Font.
-- 
-- @function [parent = #graphics] setNewFont
-- @param #File file A File with the font.
-- @param #number size The size of the font.
-- @return #Font font The new font.

---
-- Creates and sets a new Font.
-- 
-- @function [parent = #graphics] setNewFont
-- @param #Data data A Data with the font.
-- @param #number size The size of the font.
-- @return #Font font The new font.

---
-- Creates and sets a new Font.
-- 
-- @function [parent = #graphics] setNewFont
-- @param #Rasterizer rasterizer A rasterizer.
-- @return #Font font The new font.

---
-- Gets the current background color.
-- 
-- @function [parent = #graphics] getBackgroundColor
-- @return #number r The red component (0-255).
-- @return #number g The green component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).

---
-- Gets the blending mode.
-- 
-- @function [parent = #graphics] getBlendMode
-- @return #BlendMode mode The current blend mode.

---
-- Gets the current target Canvas.
-- 
-- @function [parent = #graphics] getCanvas
-- @return #Canvas canvas The Canvas set by setCanvas. Returns nil if drawing to the real screen.

---
-- Gets the current color.
-- 
-- @function [parent = #graphics] getColor
-- @return #number r The red component (0-255).
-- @return #number g The green component (0-255).
-- @return #number b The blue component (0-255).
-- @return #number a The alpha component (0-255).

---
-- Gets the active color components used when drawing. Normally all 4 components 
-- are active unless love.graphics.setColorMask has been used.
-- 
-- The color mask determines whether individual components of the colors of drawn 
-- objects will affect the color of the screen. They affect love.graphics.clear 
-- and Canvas:clear as well.
-- 
-- @function [parent = #graphics] getColorMask
-- @return #boolean r Whether the red color component is active when rendering.
-- @return #boolean g Whether the green color component is active when rendering.
-- @return #boolean b Whether the blue color component is active when rendering.
-- @return #boolean a Whether the alpha color component is active when rendering.

---
-- Gets the color mode (which controls how images are affected by the current color).
-- 
-- @function [parent = #graphics] getColorMode
-- @return #ColorMode mode The current color mode.

---
-- Returns the default scaling filters used with Images, Canvases, and Fonts.
-- 
-- @function [parent = #graphics] getDefaultFilter
-- @return #FilterMode min Filter mode used when scaling the image down.
-- @return #FilterMode mag Filter mode used when scaling the image up.
-- @return #number anisotropy Maximum amount of Anisotropic Filtering used.

---
-- Returns the default scaling filters.
-- 
-- @function [parent = #graphics] getDefaultImageFilter
-- @return #FilterMode min Filter mode used when scaling the image down.
-- @return #FilterMode mag Filter mode used when scaling the image up.

---
-- Gets the current Font object.
-- 
-- @function [parent = #graphics] getFont
-- @return #Font font The current Font. Automatically creates and sets the default font, if none is set yet.

---
-- Gets the current Font object.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #graphics] getFont
-- @return #Font font The current Font, or nil if none is set.

---
-- Gets the line join style.
-- 
-- @function [parent = #graphics] getLineJoin
-- @return #LineJoin join The LineJoin style.

---
-- Gets the current line stipple.
-- 
-- @function [parent = #graphics] getLineStipple
-- @return #number pattern The 16-bit stipple pattern.
-- @return #number repeat The repeat factor.

---
-- Gets the line style.
-- 
-- @function [parent = #graphics] getLineStyle
-- @return #LineStyle style The current line style.

---
-- Gets the current line width.
-- 
-- @function [parent = #graphics] getLineWidth
-- @return #number width The current line width.

---
-- Gets the max supported width or height of Images and Canvases.
-- 
-- Attempting to create an Image with a width *or* height greater than this number 
-- will create a checkerboard-patterned image instead. Doing the same for a canvas 
-- will result in an error.
-- 
-- The returned number depends on the system running the code. It is safe to assume 
-- it will never be less than 1024 and will almost always be 2048 or greater.
-- 
-- @function [parent = #graphics] getMaxImageSize
-- @return #number size The max supported width or height of Images and Canvases.

---
-- Gets the max supported point size.
-- 
-- @function [parent = #graphics] getMaxPointSize
-- @return #number size The max supported point size.

---
-- Returns the current PixelEffect. Returns nil if none is set.
-- 
-- @function [parent = #graphics] getPixelEffect
-- @return #PixelEffect pe The current PixelEffect.

---
-- Gets the point size.
-- 
-- @function [parent = #graphics] getPointSize
-- @return #number size The current point size.

---
-- Gets the current point style.
-- 
-- @function [parent = #graphics] getPointStyle
-- @return #PointStyle style The current point style.

---
-- Gets information about the system's video card and drivers.
-- 
-- @function [parent = #graphics] getRendererInfo
-- @return #string name The name of the renderer, e.g. "OpenGL".
-- @return #string version The version of the renderer with some extra driver-dependent version info, e.g. "2.1 INTEL-8.10.44".
-- @return #string vendor The name of the graphics card vendor, e.g. "Intel Inc."
-- @return #string device The name of the graphics card, e.g. "Intel HD Graphics 3000 OpenGL Engine".

---
-- Gets the current scissor box.
-- 
-- @function [parent = #graphics] getScissor
-- @return #number x The x-component of the top-left point of the box.
-- @return #number y The y-component of the top-left point of the box.
-- @return #number width The width of the box.
-- @return #number height The height of the box.

---
-- Gets the current Shader. Returns nil if none is set.
-- 
-- @function [parent = #graphics] getShader
-- @return #Shader shader The currently active Shader, or nil if none is set.

---
-- Gets the system-dependent maximum value for a love.graphics feature.
-- 
-- @function [parent = #graphics] getSystemLimit
-- @param #GraphicsLimit limittype The graphics feature to get the maximum value of.
-- @return #number limit The system-dependent max value for the feature.

---
-- Checks if certain graphics functions can be used.
-- 
-- Older and low-end systems do not always support all graphics extensions.
-- 
-- @function [parent = #graphics] isSupported
-- @param #GraphicsFeature supportN The graphics feature to check for.
-- @return #boolean isSupported True if everything is supported, false otherwise.

---
-- Gets whether wireframe mode is used when drawing.
-- 
-- @function [parent = #graphics] isWireframe
-- @return #boolean wireframe True if wireframe lines are used when drawing, false if it's not.

---
-- Resets the current graphics settings.
-- 
-- Calling reset makes the current drawing color white, the current background 
-- color black, disables any active Canvas or Shader, and removes any scissor 
-- settings. It sets the BlendMode to alpha, enables all color component masks, 
-- disables wireframe mode and resets the current graphics transformation to 
-- the origin. It also sets both the point and line drawing modes to smooth and their 
-- sizes to 1.0.
-- 
-- @function [parent = #graphics] reset

---
-- Sets the background color.
-- 
-- @function [parent = #graphics] setBackgroundColor
-- @param #number red The red component (0-255).
-- @param #number green The green component (0-255).
-- @param #number blue The blue component (0-255).

---
-- Sets the background color.
-- 
-- @function [parent = #graphics] setBackgroundColor
-- @param #number red The red component (0-255).
-- @param #number green The green component (0-255).
-- @param #number blue The blue component (0-255).
-- @param #number alpha The alpha component (0-255).

---
-- Sets the background color.
-- 
-- @function [parent = #graphics] setBackgroundColor
-- @param #table rgb A numerical indexed table with the red, green and blue values as numbers.

---
-- Sets the background color.
-- 
-- @function [parent = #graphics] setBackgroundColor
-- @param #table rgba A numerical indexed table with the red, green, blue and alpha values as numbers.

---
-- Sets the blending mode.
-- 
-- @function [parent = #graphics] setBlendMode
-- @param #BlendMode mode The blend mode to use.

---
-- @function [parent = #graphics] setCanvas
-- @param #Canvas canvas The new target.

---
-- @function [parent = #graphics] setCanvas

---
-- @function [parent = #graphics] setCanvas
-- @param #Canvas canvas1 The first render target.
-- @param #Canvas canvas2 The second render target.
-- @param #Canvas ... More canvases.

---
-- Sets the color used for drawing.
-- 
-- @function [parent = #graphics] setColor
-- @param #number red The amount of red.
-- @param #number green The amount of green.
-- @param #number blue The amount of blue.
-- @param #number alpha The amount of alpha. The alpha value will be applied to all subsequent draw operations, even the drawing of an image.

---
-- Sets the color used for drawing.
-- 
-- @function [parent = #graphics] setColor
-- @param #table rgba A numerical indexed table with the red, green, blue and alpha values as numbers. The alpha is optional and defaults to 255 if it is left out.

---
-- Sets the color mask. Enables or disables specific color components when rendering 
-- and clearing the screen. For example, if red is set to false, no further changes 
-- will be made to the red component of any pixels.
-- 
-- @function [parent = #graphics] setColorMask
-- @param #boolean red Render red component.
-- @param #boolean green Render green component.
-- @param #boolean blue Render blue component.
-- @param #boolean alpha Render alpha component.

---
-- Sets the color mask. Enables or disables specific color components when rendering 
-- and clearing the screen. For example, if red is set to false, no further changes 
-- will be made to the red component of any pixels.
-- 
-- @function [parent = #graphics] setColorMask

---
-- Sets the color mode (which controls how images are affected by the current color).
-- 
-- @function [parent = #graphics] setColorMode
-- @param #ColorMode mode The color mode to use.

---
-- Sets the default scaling filters used with Images, Canvases, and Fonts.
-- 
-- @function [parent = #graphics] setDefaultFilter
-- @param #FilterMode min Filter mode used when scaling the image down.
-- @param #FilterMode mag Filter mode used when scaling the image up.
-- @param #number anisotropy Maximum amount of Anisotropic Filtering used.

---
-- Sets the default scaling filters.
-- 
-- @function [parent = #graphics] setDefaultImageFilter
-- @param #FilterMode min Filter mode used when scaling the image down.
-- @param #FilterMode mag Filter mode used when scaling the image up.

---
-- Set an already-loaded Font as the current font or create and load a new one from 
-- the file and size.
-- 
-- It's recommended that Font objects are created with love.graphics.newFont 
-- in the loading stage and then passed to this function in the drawing stage.
-- 
-- @function [parent = #graphics] setFont
-- @param #Font font The Font object to use.

---
-- Set an already-loaded Font as the current font or create and load a new one from 
-- the file and size.
-- 
-- It's recommended that Font objects are created with love.graphics.newFont 
-- in the loading stage and then passed to this function in the drawing stage.
-- 
-- Removed in LÖVE 0.8.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #graphics] setFont
-- @param #string filename The filepath to the font.
-- @param #number size The size of the font.

---
-- Set an already-loaded Font as the current font or create and load a new one from 
-- the file and size.
-- 
-- It's recommended that Font objects are created with love.graphics.newFont 
-- in the loading stage and then passed to this function in the drawing stage.
-- 
-- Removed in LÖVE 0.8.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #graphics] setFont
-- @param #number size The size of the font.

---
-- Defines an inverted stencil for the drawing operations or releases the active 
-- one.
-- 
-- It's the same as love.graphics.setStencil with the mask inverted.
-- 
-- @function [parent = #graphics] setInvertedStencil
-- @param #function stencilFunction Function that draws the stencil.

---
-- Defines an inverted stencil for the drawing operations or releases the active 
-- one.
-- 
-- It's the same as love.graphics.setStencil with the mask inverted.
-- 
-- @function [parent = #graphics] setInvertedStencil

---
-- Sets the line width and style.
-- 
-- @function [parent = #graphics] setLine
-- @param #number width The width of the line.
-- @param #LineStyle style The LineStyle to use.

---
-- Sets the line join style. See LineJoin for the possible options.
-- 
-- @function [parent = #graphics] setLineJoin
-- @param #LineJoin join The LineJoin to use.

---
-- Sets the line stipple pattern.
-- 
-- @function [parent = #graphics] setLineStipple
-- @param #number pattern A 16-bit pattern.
-- @param #number repeat Repeat factor.

---
-- Sets the line style.
-- 
-- @function [parent = #graphics] setLineStyle
-- @param #LineStyle style The LineStyle to use. Line styles include smooth and rough.

---
-- Sets the line width.
-- 
-- @function [parent = #graphics] setLineWidth
-- @param #number width The width of the line.

---
-- Sets or resets a PixelEffect as the current pixel effect. All drawing operations 
-- until the next love.graphics.setPixelEffect will be drawn using the PixelEffect 
-- object specified.
-- 
-- @function [parent = #graphics] setPixelEffect
-- @param #PixelEffect pixeleffect The new pixel effect.

---
-- Sets or resets a PixelEffect as the current pixel effect. All drawing operations 
-- until the next love.graphics.setPixelEffect will be drawn using the PixelEffect 
-- object specified.
-- 
-- @function [parent = #graphics] setPixelEffect

---
-- Sets the point size and style.
-- 
-- @function [parent = #graphics] setPoint
-- @param #number size The new point size.
-- @param #PointStyle style The new point style.

---
-- Sets the point size.
-- 
-- @function [parent = #graphics] setPointSize
-- @param #number size The new point size.

---
-- Sets the point style.
-- 
-- @function [parent = #graphics] setPointStyle
-- @param #PointStyle style The new point style.

---
-- Sets or resets a Framebuffer as render target. All drawing operations until 
-- the next love.graphics.setRenderTarget will be directed to the Framebuffer 
-- object specified.
-- 
-- @function [parent = #graphics] setRenderTarget
-- @param #Framebuffer framebuffer The new render target.

---
-- Sets or resets a Framebuffer as render target. All drawing operations until 
-- the next love.graphics.setRenderTarget will be directed to the Framebuffer 
-- object specified.
-- 
-- @function [parent = #graphics] setRenderTarget

---
-- Sets or disables scissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects 
-- all graphics calls, including love.graphics.clear.
-- 
-- The dimensions of the scissor is unaffected by graphical transformations 
-- (translate, scale, ...).
-- 
-- @function [parent = #graphics] setScissor
-- @param #number x x coordinate of upper left corner.
-- @param #number y y coordinate of upper left corner.
-- @param #number width width of clipping rectangle.
-- @param #number height height of clipping rectangle.

---
-- Sets or disables scissor.
-- 
-- The scissor limits the drawing area to a specified rectangle. This affects 
-- all graphics calls, including love.graphics.clear.
-- 
-- The dimensions of the scissor is unaffected by graphical transformations 
-- (translate, scale, ...).
-- 
-- @function [parent = #graphics] setScissor

---
-- Sets or resets a Shader as the current pixel effect or vertex shaders. All drawing 
-- operations until the next love.graphics.setShader will be drawn using the 
-- Shader object specified.
-- 
-- @function [parent = #graphics] setShader
-- @param #Shader shader The new shader.

---
-- Sets or resets a Shader as the current pixel effect or vertex shaders. All drawing 
-- operations until the next love.graphics.setShader will be drawn using the 
-- Shader object specified.
-- 
-- @function [parent = #graphics] setShader

---
-- Defines or releases a stencil for the drawing operations.
-- 
-- The passed function draws to the stencil instead of the screen, creating an 
-- image with transparent and opaque pixels. While active, it is used to test where 
-- pixels will be drawn or discarded. Image contents do not directly affect the 
-- stencil, but see below for a workaround.
-- 
-- Calling the function without arguments releases the active stencil.
-- 
-- @function [parent = #graphics] setStencil
-- @param #function stencilFunction Function that draws the stencil.

---
-- Defines or releases a stencil for the drawing operations.
-- 
-- The passed function draws to the stencil instead of the screen, creating an 
-- image with transparent and opaque pixels. While active, it is used to test where 
-- pixels will be drawn or discarded. Image contents do not directly affect the 
-- stencil, but see below for a workaround.
-- 
-- Calling the function without arguments releases the active stencil.
-- 
-- @function [parent = #graphics] setStencil

---
-- Sets whether wireframe lines will be used when drawing.
-- 
-- @function [parent = #graphics] setWireframe
-- @param #boolean enable True to enable wireframe mode when drawing, false to disable it.

---
-- Resets the current coordinate transformation.
-- 
-- This function is always used to reverse any previous calls to love.graphics.rotate, 
-- love.graphics.scale, love.graphics.shear or love.graphics.translate. 
-- It returns the current transformation state to its defaults.
-- 
-- @function [parent = #graphics] origin

---
-- Pops the current coordinate transformation from the transformation stack.
-- 
-- This function is always used to reverse a previous push operation. It returns 
-- the current transformation state to what it was before the last preceding push.
-- 
-- @function [parent = #graphics] pop

---
-- Copies and pushes the current coordinate transformation to the transformation 
-- stack.
-- 
-- This function is always used to prepare for a corresponding pop operation later. 
-- It stores the current coordinate transformation state into the transformation 
-- stack and keeps it active. Later changes to the transformation can be undone 
-- by using the pop operation, which returns the coordinate transform to the state 
-- it was in before calling push.
-- 
-- @function [parent = #graphics] push

---
-- Rotates the coordinate system in two dimensions.
-- 
-- Calling this function affects all future drawing operations by rotating the 
-- coordinate system around the origin by the given amount of radians. This change 
-- lasts until love.draw() exits.
-- 
-- @function [parent = #graphics] rotate
-- @param #number angle The amount to rotate the coordinate system in radians.

---
-- Scales the coordinate system in two dimensions.
-- 
-- By default the coordinate system in LÖVE corresponds to the display pixels 
-- in horizontal and vertical directions one-to-one, and the x-axis increases 
-- towards the right while the y-axis increases downwards. Scaling the coordinate 
-- system changes this relation.
-- 
-- After scaling by sx and sy, all coordinates are treated as if they were multiplied 
-- by sx and sy. Every result of a drawing operation is also correspondingly scaled, 
-- so scaling by (2, 2) for example would mean making everything twice as large 
-- in both x- and y-directions. Scaling by a negative value flips the coordinate 
-- system in the corresponding direction, which also means everything will be 
-- drawn flipped or upside down, or both. Scaling by zero is not a useful operation.
-- 
-- Scale and translate are not commutative operations, therefore, calling them 
-- in different orders will change the outcome.
-- 
-- Scaling lasts until love.draw() exits.
-- 
-- @function [parent = #graphics] scale
-- @param #number sx The scaling in the direction of the x-axis.
-- @param #number sy The scaling in the direction of the y-axis. If omitted, it defaults to same as parameter sx.

---
-- Shears the coordinate system.
-- 
-- @function [parent = #graphics] shear
-- @param #number kx The shear factor on the x-axis.
-- @param #number ky The shear factor on the y-axis.

---
-- Translates the coordinate system in two dimensions.
-- 
-- When this function is called with two numbers, dx, and dy, all the following 
-- drawing operations take effect as if their x and y coordinates were x+dx and 
-- y+dy.
-- 
-- Scale and translate are not commutative operations, therefore, calling them 
-- in different orders will change the outcome.
-- 
-- This change lasts until love.draw() exits or else a love.graphics.pop reverts 
-- to a previous love.graphics.push.
-- 
-- Translating using whole numbers will prevent tearing/blurring of images 
-- and fonts draw after translating.
-- 
-- @function [parent = #graphics] translate
-- @param #number dx The translation relative to the x-axis.
-- @param #number dy The translation relative to the y-axis.

---
-- Checks if a display mode is supported.
-- 
-- @function [parent = #graphics] checkMode
-- @param #number width The display width.
-- @param #number height The display height.
-- @param #boolean fullscreen True to check for fullscreen, false for windowed.
-- @return #boolean supported True if supported, false if not.

---
-- Gets the window caption.
-- 
-- @function [parent = #graphics] getCaption
-- @return #string caption The current window caption.

---
-- Gets the width and height in pixels of the window.
-- 
-- @function [parent = #graphics] getDimensions
-- @return #number width The width of the window.
-- @return #number height The height of the window.

---
-- Gets the height in pixels of the window.
-- 
-- @function [parent = #graphics] getHeight
-- @return #number height The height of the window.

---
-- Returns the current display mode.
-- 
-- @function [parent = #graphics] getMode
-- @return #number width Display width.
-- @return #number height Display height.
-- @return #boolean fullscreen Fullscreen (true) or windowed (false).
-- @return #boolean vsync True if vertical sync is enabled or false if disabled.
-- @return #number fsaa The number of FSAA samples.

---
-- Gets a list of supported fullscreen modes.
-- 
-- @function [parent = #graphics] getModes
-- @return #table modes A table of width/height pairs. (Note that this may not be in order.)

---
-- Gets the width in pixels of the window.
-- 
-- @function [parent = #graphics] getWidth
-- @return #number width The width of the window.

---
-- Checks if the game window has keyboard focus.
-- 
-- @function [parent = #graphics] hasFocus
-- @return #boolean focus True if the window has the focus or false if not.

---
-- Checks if the window has been created.
-- 
-- @function [parent = #graphics] isCreated
-- @return #boolean created True if the window has been created, false otherwise.

---
-- Sets the window caption.
-- 
-- @function [parent = #graphics] setCaption
-- @param #string caption The new window caption.

---
-- Set window icon. This feature is not completely supported on Windows (apparently 
-- an SDL bug, not a LOVE bug: [1]).
-- 
-- @function [parent = #graphics] setIcon
-- @param #Image image The window icon.

---
-- Changes the window size, or the display mode if fullscreen.
-- 
-- If width or height is 0, setMode will use the width or height of the desktop.
-- 
-- Changing the display mode may have side effects: for example, Canvases will 
-- be cleared; make sure to save their contents beforehand.
-- 
-- @function [parent = #graphics] setMode
-- @param #number width Display width.
-- @param #number height Display height.
-- @param #boolean fullscreen Fullscreen (true), or windowed (false).
-- @param #boolean vsync True if LÖVE should wait for vsync, false otherwise.
-- @param #number fsaa The number of FSAA-buffers.
-- @return #boolean success True if successful, false otherwise.

---
-- Toggles fullscreen.
-- 
-- @function [parent = #graphics] toggleFullscreen
-- @return #boolean success True if successful, false otherwise.


return nil
