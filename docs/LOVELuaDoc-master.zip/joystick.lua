---
-- Provides an interface to connected joysticks.
-- 
-- @module joystick
--

---
-- Closes a joystick, i.e. stop using it for generating events and in query functions.
-- 
-- @function [parent = #joystick] close
-- @param #number joystick The joystick to be closed

---
-- Returns the position of each axis.
-- 
-- @function [parent = #joystick] getAxes
-- @param #number joystick The joystick to be checked
-- @return #number axisDir1 Direction of axis1
-- @return #number axisDir2 Direction of axis2
-- @return #number axisDirN Direction of axisN

---
-- Returns the direction of the axis.
-- 
-- @function [parent = #joystick] getAxis
-- @param #number joystick The joystick to be checked
-- @param #number axis The axis to be checked
-- @return #number direction Current value of the axis

---
-- Returns the change in ball position.
-- 
-- @function [parent = #joystick] getBall
-- @param #number joystick The joystick to be checked
-- @param #number ball The ball to be checked
-- @return #number dx Change in x of the ball position.
-- @return #number dy Change in y of the ball position.

---
-- Returns the direction of a hat.
-- 
-- @function [parent = #joystick] getHat
-- @param #number joystick The joystick to be checked
-- @param #number hat The hat to be checked
-- @return #JoystickConstant direction The direction the hat is pushed

---
-- Gets the number of connected joysticks.
-- 
-- @function [parent = #joystick] getJoystickCount
-- @return #number joystickcount The number of connected joysticks.

---
-- Gets a list of connected Joysticks.
-- 
-- @function [parent = #joystick] getJoysticks
-- @return #table joysticks The list of currently connected Joysticks.

---
-- Returns the name of a joystick.
-- 
-- @function [parent = #joystick] getName
-- @param #number joystick The joystick to be checked
-- @return #string name The name

---
-- Returns the number of axes on the joystick.
-- 
-- @function [parent = #joystick] getNumAxes
-- @param #number joystick The joystick to be checked
-- @return #number axes The number of axes available

---
-- Returns the number of balls on the joystick.
-- 
-- @function [parent = #joystick] getNumBalls
-- @param #number joystick The joystick to be checked
-- @return #number balls The number of balls available

---
-- Returns the number of buttons on the joystick.
-- 
-- @function [parent = #joystick] getNumButtons
-- @param #number joystick The joystick to be checked
-- @return #number buttons The number of buttons available

---
-- Returns the number of hats on the joystick.
-- 
-- @function [parent = #joystick] getNumHats
-- @param #number joystick The joystick to be checked
-- @return #number hats How many hats the joystick has

---
-- Returns how many joysticks are available.
-- 
-- @function [parent = #joystick] getNumJoysticks
-- @return #number joysticks The number of joysticks available

---
-- Checks if a button on a joystick is pressed.
-- 
-- @function [parent = #joystick] isDown
-- @param #number joystick The joystick to be checked
-- @param #number button The button to be checked
-- @return #boolean down True if the button is down, false if it is not

---
-- Checks if a button on a joystick is pressed.
-- 
-- @function [parent = #joystick] isDown
-- @param #number joystick The joystick to be checked
-- @param #number buttonN A button to check
-- @return #boolean anyDown True if any supplied button is down, false if not.

---
-- Checks if the joystick is open.
-- 
-- @function [parent = #joystick] isOpen
-- @param #number joystick The joystick to be checked
-- @return #boolean open True if the joystick is open, false if it is closed.

---
-- Opens up a joystick to be used, i.e. makes it ready to use. By default joysticks 
-- that are available at the start of your game will be opened. NOTE: Unlike conventional 
-- Lua indexes, joysticks begin counting from 0 in LÖVE 0.7.2 and below. To to open 
-- the first joystick, you would use love.joystick.open(0). This is not the case 
-- in LÖVE 0.8.0 and later.
-- 
-- @function [parent = #joystick] open
-- @param #number joystick The joystick to be opened
-- @return #boolean open True if the joystick has been successfully opened or false on failure.

---
-- Binds a virtual gamepad input to a button, axis or hat for all Joysticks of a certain 
-- type. For example, if this function is used with a GUID returned by a Dualshock 
-- 3 controller in OS X, the binding will affect Joystick:getGamepadAxis and 
-- Joystick:isGamepadDown for all Dualshock 3 controllers used with the game 
-- when run in OS X.
-- 
-- LÖVE includes built-in gamepad bindings for many common controllers. This 
-- function lets you change the bindings or add new ones for types of Joysticks 
-- which aren't recognized as gamepads by default.
-- 
-- The virtual gamepad buttons and axes are designed around the Xbox 360 controller 
-- layout.
-- 
-- @function [parent = #joystick] setGamepadMapping
-- @param #string guid The OS-dependent GUID for the type of Joystick the binding will affect.
-- @param #GamepadButton button The virtual gamepad button to bind.
-- @param #JoystickInputType inputtype The type of input to bind the virtual gamepad button to.
-- @param #number inputindex The index of the axis, button, or hat to bind the virtual gamepad button to.
-- @param #JoystickHat hatdir The direction of the hat, if the virtual gamepad button will be bound to a hat. nil otherwise.
-- @return #boolean success Whether the virtual gamepad button was successfully bound.

---
-- Binds a virtual gamepad input to a button, axis or hat for all Joysticks of a certain 
-- type. For example, if this function is used with a GUID returned by a Dualshock 
-- 3 controller in OS X, the binding will affect Joystick:getGamepadAxis and 
-- Joystick:isGamepadDown for all Dualshock 3 controllers used with the game 
-- when run in OS X.
-- 
-- LÖVE includes built-in gamepad bindings for many common controllers. This 
-- function lets you change the bindings or add new ones for types of Joysticks 
-- which aren't recognized as gamepads by default.
-- 
-- The virtual gamepad buttons and axes are designed around the Xbox 360 controller 
-- layout.
-- 
-- @function [parent = #joystick] setGamepadMapping
-- @param #string guid The OS-dependent GUID for the type of Joystick the binding will affect.
-- @param #GamepadAxis axis The virtual gamepad axis to bind.
-- @param #JoystickInputType inputtype The type of input to bind the virtual gamepad axis to.
-- @param #number inputindex The index of the axis, button, or hat to bind the virtual gamepad axis to.
-- @param #JoystickHat hatdir The direction of the hat, if the virtual gamepad axis will be bound to a hat. nil otherwise.
-- @return #boolean success Whether the virtual gamepad axis was successfully bound.


return nil
