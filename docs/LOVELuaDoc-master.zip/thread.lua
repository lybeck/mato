---
-- Allows you to work with threads.
-- 
-- Threads are separate Lua environments, running in parallel to the main code. 
-- As their code runs separately, they can be used to compute complex operations 
-- without adversely affecting the frame rate of the main thread. However, as 
-- they are separate environments, they cannot access the variables and functions 
-- of the main thread, and communication between threads is limited.
-- 
-- All LOVE objects (userdata) are shared among threads so you'll only have to 
-- send their references across threads. You may run into concurrency issues 
-- if you manipulate an object on multiple threads at the same time.
-- 
-- When a Thread is started, it only loads the love.thread module. Every other 
-- module has to be loaded with require.
-- 
-- @module thread
--

---
-- Creates or retrieves a named thread channel.
-- 
-- @function [parent = #thread] getChannel
-- @param #string name The name of the channel you want to create or retrieve.
-- @return #Channel channel The Channel object associated with the name.

---
-- Look for a thread and get its object.
-- 
-- @function [parent = #thread] getThread
-- @param #string name The name of the thread to return.
-- @return #Thread thread The thread with that name.

---
-- Look for a thread and get its object.
-- 
-- @function [parent = #thread] getThread
-- @return #Thread thread The current thread.

---
-- Get all threads.
-- 
-- @function [parent = #thread] getThreads
-- @return #table threads A table containing all threads indexed by their names.

---
-- Create a new unnamed thread channel.
-- 
-- One use for them is to pass new unnamed channels to other threads via Channel:push 
-- on a named channel.
-- 
-- @function [parent = #thread] newChannel
-- @return #Channel channel The new Channel object.

---
-- Creates a new Thread from a Lua file or FileData object.
-- 
-- @function [parent = #thread] newThread
-- @param #string filename The name of the Lua file to use as the source.
-- @return #Thread thread A new Thread that has yet to be started.

---
-- Creates a new Thread from a Lua file or FileData object.
-- 
-- @function [parent = #thread] newThread
-- @param #FileData fileData The FileData containing the Lua code to use as the source.
-- @return #Thread thread A new Thread that has yet to be started.

---
-- Creates a new Thread from a Lua file or FileData object.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #thread] newThread
-- @param #string name The name of the thread.
-- @param #string filename The name of the File to use as source.
-- @return #Thread thread A new Thread that has yet to be started.

---
-- Creates a new Thread from a Lua file or FileData object.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #thread] newThread
-- @param #string name The name of the thread.
-- @param #File file The file to use as source.
-- @return #Thread thread A new Thread that has yet to be started.

---
-- Creates a new Thread from a Lua file or FileData object.
-- 
-- Removed in LÖVE 0.9.0 This variant is not supported in that and later versions.
-- 
-- @function [parent = #thread] newThread
-- @param #string name The name of the thread.
-- @param #Data data The data to use as source.
-- @return #Thread thread A new Thread that has yet to be started.


return nil
