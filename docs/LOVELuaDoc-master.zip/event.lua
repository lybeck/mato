---
-- Manages events, like keypresses.
-- 
-- It is possible to define new events by appending the table love.handlers. Such 
-- functions can be invoked as usual, via love.event.push using the table index 
-- as an argument.
-- 
-- Dansk – Deutsch – English – Español – Français – Indonesia – Italiano – 
-- Lietuviškai – Magyar – Nederlands – Polski – Português – Română – Slovenský – 
-- Suomi – Svenska – Türkçe – Česky – Ελληνικά – Български – Русский – Српски – 
-- Українська – עברית – ไทย – 日本語 – 正體中文 – 简体中文 – Tiếng Việt – 한국어 More info
-- 
-- @module event
--

---
-- Clears the event queue.
-- 
-- @function [parent = #event] clear

---
-- Returns an iterator for messages in the event queue.
-- 
-- @function [parent = #event] poll
-- @return #function i Iterator function usable in a for loop.

---
-- Pump events into the event queue. This is a low-level function, and is usually 
-- not called by the user, but by love.run. Note that this does need to be called 
-- for any OS to think you're still running, and if you want to handle OS-generated 
-- events at all (think callbacks).
-- 
-- @function [parent = #event] pump

---
-- Adds an event to the event queue.
-- 
-- @function [parent = #event] push
-- @param #Event e The name of the event.
-- @param #mixed a First event argument.
-- @param #mixed b Second event argument.
-- @param #mixed c Third event argument.

---
-- Adds the quit event to the queue.
-- 
-- The quit event is a signal for the event handler to close LÖVE. It's possible 
-- to abort the exit process with the love.quit callback.
-- 
-- @function [parent = #event] quit

---
-- Like love.event.poll(), but blocks until there is an event in the queue.
-- 
-- @function [parent = #event] wait
-- @return #Event e The type of event.
-- @return #mixed a First event argument.
-- @return #mixed b Second event argument.
-- @return #mixed c Third event argument.
-- @return #mixed d Fourth event argument.


return nil
